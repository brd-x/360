package com.example.myapplicationd;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuView;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Database database;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = new Database(MainActivity.this);

        ListView itemView = findViewById(R.id.itemList);
        ListView quantityView = findViewById(R.id.quantityList);

        View vert = findViewById(R.id.vert);
        vert.setVisibility(View.INVISIBLE);
        itemView.setVisibility(View.INVISIBLE);
        quantityView.setVisibility(View.INVISIBLE);
        Button login = findViewById(R.id.login);
        Button register = findViewById(R.id.register);
        Button add = findViewById(R.id.add);
        Button delete = findViewById(R.id.delete);
        add.setVisibility(View.INVISIBLE);
        delete.setVisibility(View.INVISIBLE);
        TextView usernameL = findViewById(R.id.UsernameLabel);
        TextView passwordL = findViewById(R.id.PasswordLabel);
        TextView username = findViewById(R.id.usernameInput);
        TextView password = findViewById(R.id.passwordInput);
        final String[] userUsername = {""};
        final String[] userPassword = {""};

        final ArrayAdapter<String> itemAdapter = new ArrayAdapter
                (MainActivity.this, android.R.layout.simple_list_item_1, database.readItems());
        itemView.setAdapter(itemAdapter);

        login.setOnClickListener(view -> {
            String usernameTest1 = username.getText().toString();
            String passwordTest1 = password.getText().toString();
            if (usernameTest1.equals(userUsername[0])&&passwordTest1.equals(userPassword[0]))
            {
                login.setVisibility(View.INVISIBLE);
                register.setVisibility(View.INVISIBLE);
                username.setVisibility(View.INVISIBLE);
                password.setVisibility(View.INVISIBLE);
                usernameL.setVisibility(View.INVISIBLE);
                passwordL.setVisibility(View.INVISIBLE);
                vert.setVisibility(View.VISIBLE);
                itemView.setVisibility(View.VISIBLE);
                quantityView.setVisibility(View.VISIBLE);
                add.setVisibility(View.VISIBLE);
                delete.setVisibility(View.VISIBLE);
                itemAdapter.notifyDataSetChanged();
            }
            else
            {
                username.setText("Incorrect info.");
            }


        });


        register.setOnClickListener(view -> {

            userUsername[0] = username.getText().toString();
            userPassword[0] = password.getText().toString();
            username.setText("Info saved.");

        });

        add.setOnClickListener(view -> {

            database.addNewItem("sample", 89);

            itemAdapter.notifyDataSetChanged();
        });

        delete.setOnClickListener(view -> {
            itemAdapter.notifyDataSetChanged();
        });

    }

    public void frag2()
    {


    }

}